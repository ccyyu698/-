
  # 期中報告

  This is a code bundle for 期中報告. The original project is available at https://www.figma.com/design/wYXIaduPs3kYTgNdjxlGQw/%E6%9C%9F%E4%B8%AD%E5%A0%B1%E5%91%8A.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  